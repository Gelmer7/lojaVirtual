# Sistema simples de uma loja Virtual feito em PHP, Bootstrap, PDO e MySQL

Sistema de cadastro de produtos e clientes utilizando MySQL e linguagem PHP
projeto iniciado em febereiro de 2019 

## Configuração do Projeto:

- Executar a query cliente.sql ou importar o arquivo no phpMyAdmin para criar a table necessária.
- Editar o arquivo **banco.php** 

```
$dbNome = 'nomeDaTable' 
$dbHost = 'nomeDoDominioOuIP:Porta' 
$dbUsuario = 'usuarioDoMysql' 
$dbSenha 'senhaDoUsuario'

```
